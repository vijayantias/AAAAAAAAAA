// import Cart from "../models/Cart.js";
// import Product from "../models/Product.js";

// // Add product to cart
// export const addToCart = async (req, res) => {
//   try {
//     const userId = req.user.id;
//     const { productId, quantity } = req.body;

//     const product = await Product.findById(productId);
//     if (!product) return res.status(404).json({ message: "Product not found" });

//     let cart = await Cart.findOne({ user: userId });

//     if (!cart) {
//       cart = new Cart({ user: userId, items: [], total: 0 });
//     }

//     const itemIndex = cart.items.findIndex(
//       (item) => item.product.toString() === productId
//     );

//     if (itemIndex > -1) {
//       cart.items[itemIndex].quantity += quantity;
//     } else {
//       cart.items.push({
//         product: productId,
//         quantity,
//         price: product.price,
//       });
//     }

//     cart.total = cart.items.reduce(
//       (acc, item) => acc + item.price * item.quantity,
//       0
//     );

//     await cart.save();
//     res.json(cart);
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// };

// // Get user cart
// export const getCart = async (req, res) => {
//   try {
//     const cart = await Cart.findOne({ user: req.user.id }).populate("items.product");
//     if (!cart) return res.json({ items: [], total: 0 });
//     res.json(cart);
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// };

// // Remove item from cart
// export const removeFromCart = async (req, res) => {
//   try {
//     const userId = req.user.id;
//     const { productId } = req.params;

//     const cart = await Cart.findOne({ user: userId });
//     if (!cart) return res.status(404).json({ message: "Cart not found" });

//     cart.items = cart.items.filter(
//       (item) => item.product.toString() !== productId
//     );

//     cart.total = cart.items.reduce(
//       (acc, item) => acc + item.price * item.quantity,
//       0
//     );

//     await cart.save();
//     res.json(cart);
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// };


// // Increase quantity
// export const increaseQuantity = async (req, res) => {
//   try {
//     const userId = req.user.id;
//     const { productId } = req.params;

//     const cart = await Cart.findOne({ user: userId });
//     if (!cart) return res.status(404).json({ message: "Cart not found" });

//     const item = cart.items.find(item => item.product.toString() === productId);
//     if (item) item.quantity += 1;

//     cart.total = cart.items.reduce((acc, i) => acc + i.price * i.quantity, 0);
//     await cart.save();
//     res.json(cart);
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// };

// // Decrease quantity
// export const decreaseQuantity = async (req, res) => {
//   try {
//     const userId = req.user.id;
//     const { productId } = req.params;

//     const cart = await Cart.findOne({ user: userId });
//     if (!cart) return res.status(404).json({ message: "Cart not found" });

//     const item = cart.items.find(item => item.product.toString() === productId);
//     if (item) {
//       item.quantity -= 1;
//       if (item.quantity <= 0) {
//         // remove item if quantity <= 0
//         cart.items = cart.items.filter(i => i.product.toString() !== productId);
//       }
//     }

//     cart.total = cart.items.reduce((acc, i) => acc + i.price * i.quantity, 0);
//     await cart.save();
//     res.json(cart);
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// };




import Cart from "../models/Cart.js";
import Product from "../models/Product.js";

// Add product or update quantity
export const addToCart = async (req, res) => {
  try {
    const userId = req.user.id;
    const { productId, quantity } = req.body;

    const product = await Product.findById(productId);
    if (!product) return res.status(404).json({ message: "Product not found" });

    let cart = await Cart.findOne({ user: userId });
    if (!cart) cart = new Cart({ user: userId, items: [], total: 0 });

    const itemIndex = cart.items.findIndex(
      (item) => item.product.toString() === productId
    );

    if (itemIndex > -1) {
      // Update existing quantity
      cart.items[itemIndex].quantity += quantity;
      cart.items[itemIndex].price = cart.items[itemIndex].quantity * product.price;
    } else {
      // Add new item
      cart.items.push({ product: productId, quantity: 1, price: product.price});
    }


    // Recalculate total
    cart.total = cart.items.reduce((sum, item) => sum + item.price, 0);
    await cart.save();

    // Populate product details for frontend
    const populatedCart = await cart.populate("items.product");
    res.json(populatedCart);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Get cart
export const getCart = async (req, res) => {
  try {
    const cart = await Cart.findOne({ user: req.user.id }).populate("items.product");
    if (!cart) return res.json({ items: [], total: 0 });
    res.json(cart);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Remove item
export const removeFromCart = async (req, res) => {
  try {
    const { productId } = req.params;
    const cart = await Cart.findOne({ user: req.user.id });
    if (!cart) return res.status(404).json({ message: "Cart not found" });

    cart.items = cart.items.filter((item) => item.product.toString() !== productId);
    cart.total = cart.items.reduce((sum, item) => sum + item.price, 0);

    await cart.save();
    const populatedCart = await cart.populate("items.product");
    res.json(populatedCart);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Increase quantity
export const increaseQuantity = async (req, res) => {
  try {
    const { productId } = req.params;
    const cart = await Cart.findOne({ user: req.user.id });
    if (!cart) return res.status(404).json({ message: "Cart not found" });

    const item = cart.items.find((i) => i.product.toString() === productId);
    if (!item) return res.status(404).json({ message: "Product not in cart" });

    item.quantity += 1;
    item.price = item.quantity * item.price / (item.quantity - 1); // fix per unit price
    cart.total = cart.items.reduce((sum, i) => sum + i.price, 0);

    await cart.save();
    const populatedCart = await cart.populate("items.product");
    res.json(populatedCart);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Decrease quantity
export const decreaseQuantity = async (req, res) => {
  try {
    const { productId } = req.params;
    const cart = await Cart.findOne({ user: req.user.id });
    if (!cart) return res.status(404).json({ message: "Cart not found" });

    const item = cart.items.find((i) => i.product.toString() === productId);
    if (!item) return res.status(404).json({ message: "Product not in cart" });

    item.quantity -= 1;
    if (item.quantity <= 0) {
      cart.items = cart.items.filter((i) => i.product.toString() !== productId);
    } else {
      item.price = item.quantity * item.price / (item.quantity + 1); // fix per unit price
    }

    cart.total = cart.items.reduce((sum, i) => sum + i.price, 0);
    await cart.save();
    const populatedCart = await cart.populate("items.product");
    res.json(populatedCart);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
