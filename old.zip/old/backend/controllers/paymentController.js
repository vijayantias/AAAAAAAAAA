// controllers/paymentController.js
import dotenv from 'dotenv';
dotenv.config();

import Stripe from 'stripe';
import Order from '../models/orderModel.js';
import Cart from '../models/Cart.js';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// 1️⃣ Create PaymentIntent
export const createPaymentIntent = async (req, res) => {
  try {
    const userId = req.user._id.toString(); // must be string
    const cart = await Cart.findOne({ user: userId }).populate("items.product");

    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ message: "Cart is empty" });
    }

    const total = cart.items.reduce(
      (sum, item) => sum + item.product.price * item.quantity,
      0
    );

    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(total * 100),
      currency: "inr",
      metadata: { userId }, // string
    });

    res.status(200).json({
      clientSecret: paymentIntent.client_secret,
      total,
    });
  } catch (error) {
    console.error("Stripe Error:", error);
    res.status(500).json({ message: "Payment failed", error: error.message });
  }
};

// 2️⃣ Confirm Order after successful payment
export const confirmOrder = async (req, res) => {
  try {
    const { paymentIntentId } = req.body;
    const userId = req.user._id;

    // Verify paymentIntent status
    const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
    if (paymentIntent.status !== "succeeded") {
      return res.status(400).json({ message: "Payment not successful" });
    }

    const cart = await Cart.findOne({ user: userId }).populate("items.product");
    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ message: "Cart is empty" });
    }

    const order = new Order({
      user: userId,
      items: cart.items.map(i => ({
        product: i.product._id,
        quantity: i.quantity,
        price: i.product.price,
        
      })),
      total: cart.items.reduce((sum, item) => sum + item.product.price * item.quantity, 0),
      paymentId: paymentIntent.id,
      paymentStatus: "Paid",
      orderStatus: "Processing",
    });

    await order.save();

    // Clear cart
    cart.items = [];
    await cart.save();

    res.status(201).json({ message: "Order placed successfully", order });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Order confirmation failed", error: error.message });
  }
};
