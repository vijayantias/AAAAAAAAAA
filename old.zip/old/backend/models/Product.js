// import mongoose from 'mongoose';

// const productSchema = new mongoose.Schema({
//     name: String,
//     price: Number,
//     description: String,
//     stock: Number,
// }, 
// { timestamps: true });

// export default mongoose.model('Product', productSchema);


// backend/models/Product.js
import mongoose from 'mongoose';

const productSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: { type: String, default: '' },
  price: { type: Number, required: true },
  stock: { type: Number, default: 0 },
  image: { type: String, default: '' }, // keep URL for now
  category: { type: String, default: '' }
}, { timestamps: true });

export default mongoose.model('Product', productSchema);
