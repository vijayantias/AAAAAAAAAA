// backend/routes/authRoutes.js
import express from 'express';
import { register } from '../controllers/authController.js';
import { login } from '../controllers/authController.js';


const router = express.Router();

// Test route
router.get('/test', (req, res) => {
  res.send({ message: 'Auth routes working!' });
});


// Register route
router.post('/register', register);

// Login
router.post('/login', login);

export default router;


