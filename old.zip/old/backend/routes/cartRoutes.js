import express from "express";
import { addToCart, getCart, removeFromCart, increaseQuantity, decreaseQuantity } from "../controllers/cartController.js";
import { protect } from "../middlewares/authMiddleware.js";

const router = express.Router();

router.post("/add", protect, addToCart);
router.get("/", protect, getCart);
router.delete("/remove/:productId", protect, removeFromCart);
router.put("/:productId/increase", protect, increaseQuantity);
router.put("/:productId/decrease", protect, decreaseQuantity);


export default router;
