// routes/orderRoutes.js
import express from 'express';
import { getUserOrders, getAllOrders, updateOrderStatus } from '../controllers/orderController.js';
import { protect, admin } from '../middlewares/authMiddleware.js';

const router = express.Router();

// Test route
router.get('/test', (req, res) => {
  res.send({ message: 'Order routes working!' });
});
  

// User view their own orders
router.get('/my-orders', protect, getUserOrders);

// Admin view all orders
router.get('/all', protect, admin, getAllOrders);

// Admin updates order status
router.put('/update/:orderId', protect, admin, updateOrderStatus);

export default router;

