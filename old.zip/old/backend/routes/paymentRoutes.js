import express from "express";
import { createPaymentIntent, confirmOrder } from "../controllers/paymentController.js";
import { protect } from "../middlewares/authMiddleware.js";

const router = express.Router();

router.post("/create-payment-intent", protect, createPaymentIntent);
router.post("/confirm", protect, confirmOrder);

export default router;
