import express from 'express';

import { createProduct, getProducts, getProductById, updateProduct, deleteProduct } from '../controllers/productController.js';
import { protect, admin } from '../middlewares/authMiddleware.js';

const router = express.Router();

// Test route
router.get('/test', (req, res) => {
  res.send({ message: 'Product routes working!' });
});

// Public
router.get('/', getProducts);
router.get('/:id', getProductById);

// Admin only
router.post('/', protect, admin, createProduct);
router.put('/:id', protect, admin, updateProduct);
router.delete('/:id', protect, admin, deleteProduct);

export default router;
