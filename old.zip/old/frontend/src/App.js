import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import Home from './pages/Home';
import Register from './pages/Register';
import Login from './pages/Login';
import Home2 from './pages/Home2';
// Protected Route
import UserDashboard from './pages/UserDashboard';
import AdminDashboard from './pages/AdminDashboard';
import ProtectedRoute from './components/ProtectedRoute';
import Checkout from "./pages/Checkout";
import PaymentPage from "./pages/PaymentPage";

// Produt Detail Page
// import ProductDetail from './pages/ProductDetail';
import Cart from './pages/Cart';
import CartPage from './pages/CartPage';
import { CartProvider } from './context/CartContext';
import OrderSuccess from './pages/OrderSuccess';


function App() {
  return (
    <AuthProvider>
      <CartProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/home2" element={<Home2 />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <UserDashboard />
              </ProtectedRoute>
            }
          />

          <Route
            path="/admin"
            element={
              <ProtectedRoute adminOnly={true}>
                <AdminDashboard />
              </ProtectedRoute>
            }
          />

          <Route path="/cart/:id" element={<Cart />} />
          {/* <Route path="/cart" element={<Cart />} />    */}
          <Route path="/cart" element={<CartPage />} />

          <Route path="/checkout/:id" element={<Checkout />} />
          <Route path="/checkout" element={<Checkout />} />   {/* fallback for empty checkout */}

          <Route path="/checkout/:orderId" element={<Checkout />} />
          <Route path="/payment/:orderId" element={<PaymentPage />} />

          <Route path="/order-success" element={<OrderSuccess />} />
          
          

          {/* <Route path="/product/:id" element={<ProductDetail />} /> */}

        </Routes>
      </Router>
      </CartProvider>
    </AuthProvider>
  );
}

export default App;
