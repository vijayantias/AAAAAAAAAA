// frontend/src/api/product.js
import axios from 'axios';
const API_URL = process.env.REACT_APP_API_URL + '/products';

export const createProduct = async (productData) => {
  const token = localStorage.getItem('token');
  const res = await axios.post(API_URL, productData, {
    headers: { Authorization: `Bearer ${token}` }
  });
  return res.data;
};

export const getProducts = async () => {
  const res = await axios.get(API_URL);
  return res.data;
};

export const getProductById = async (id) => {
  const res = await axios.get(`${API_URL}/${id}`);
  return res.data;
};
