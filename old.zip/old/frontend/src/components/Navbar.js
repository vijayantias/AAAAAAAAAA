import { Link, useNavigate } from 'react-router-dom';
import { useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import { Navbar as BSNavbar, Nav, Button, Container } from 'react-bootstrap';

function Navbar() {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout(); // clears localStorage & state
    navigate('/'); // redirect to home
  };

  return (
    <BSNavbar bg="dark" variant="dark" expand="lg">
      <Container>
        <BSNavbar.Brand href="/">Ecomm</BSNavbar.Brand>
        <BSNavbar.Toggle aria-controls="basic-navbar-nav" />
        <BSNavbar.Collapse id="basic-navbar-nav">
          <Nav className="ms-auto">
            {!user && (
              <>
                <Link to="/login">
                  <Button variant="outline-light" className="me-2">Login</Button>
                </Link>
                <Link to="/register">
                  <Button variant="outline-light">Register</Button>
                </Link>
              </>
            )}
            {user && (
              <>
                <span style={{ color: 'white', marginRight: '15px' }}>
                  Welcome, {user.name}
                </span>
                <Button variant="outline-light" onClick={handleLogout}>Logout</Button>
              </>
            )}
          </Nav>
        </BSNavbar.Collapse>
      </Container>
    </BSNavbar>
  );
}

export default Navbar;
