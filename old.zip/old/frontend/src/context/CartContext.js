import { createContext, useState, useEffect, useCallback } from "react";
import axios from "axios";

const API_URL = "http://localhost:5000/api";

export const CartContext = createContext();

// Helper to merge duplicate items by product._id
const mergeCartItems = (items) => {
  const map = {};
  items.forEach((item) => {
    const id = item.product._id;
    if (map[id]) {
      map[id].quantity += item.quantity;
      map[id].price = map[id].quantity * item.product.price;
    } else {
      map[id] = { ...item };
    }
  });
  return Object.values(map);
};

export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState({ items: [], total: 0 });
  const token = localStorage.getItem("token");

  // Calculate total from items
  const calculateTotal = (items) =>
    items.reduce((sum, item) => sum + item.price, 0);

  const fetchCart = useCallback(async () => {
    if (!token) return;
    try {
      const res = await axios.get(`${API_URL}/cart`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const mergedItems = mergeCartItems(res.data.items);
      setCart({ items: mergedItems, total: calculateTotal(mergedItems) });
    } catch (err) {
      console.error(err);
    }
  }, [token]);

  const addToCart = async (productId) => {
    if (!token) return;
    try {
      const res = await axios.post(
        `${API_URL}/cart/add`,
        { productId, quantity: 1 },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      const mergedItems = mergeCartItems(res.data.items);
      setCart({ items: mergedItems, total: calculateTotal(mergedItems) });
    } catch (err) {
      console.error(err);
    }
  };

  const removeFromCart = async (productId) => {
    if (!token) return;
    try {
      const res = await axios.delete(`${API_URL}/cart/remove/${productId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const mergedItems = mergeCartItems(res.data.items);
      setCart({ items: mergedItems, total: calculateTotal(mergedItems) });
    } catch (err) {
      console.error(err);
    }
  };

  const increaseQuantity = async (productId) => {
    if (!token) return;
    try {
      const res = await axios.put(`${API_URL}/cart/${productId}/increase`, {}, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const mergedItems = mergeCartItems(res.data.items);
      setCart({ items: mergedItems, total: calculateTotal(mergedItems) });
    } catch (err) {
      console.error(err);
    }
  };

  const decreaseQuantity = async (productId) => {
    if (!token) return;
    try {
      const res = await axios.put(`${API_URL}/cart/${productId}/decrease`, {}, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const mergedItems = mergeCartItems(res.data.items);
      setCart({ items: mergedItems, total: calculateTotal(mergedItems) });
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchCart();
  }, [fetchCart]);

  return (
    <CartContext.Provider
      value={{
        cart,
        addToCart,
        removeFromCart,
        increaseQuantity,
        decreaseQuantity,
        fetchCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};
