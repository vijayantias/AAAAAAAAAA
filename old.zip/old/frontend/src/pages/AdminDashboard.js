// frontend/src/pages/AdminDashboard.js
import { useState, useContext, useEffect } from 'react';
import { Button, Navbar, Nav, Form, Container, Row, Col, Card } from 'react-bootstrap';
import { AuthContext } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { createProduct, getProducts } from '../api/product';

function AdminDashboard() {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: '',
    description: '',
    price: '',
    stock: '',
    image: '',
    category: ''
  });

  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [products, setProducts] = useState([]);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const data = await getProducts();
      setProducts(data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    try {
      // basic client-side validation
      if (!form.name || form.price === '') {
        setError('Name and price are required');
        return;
      }

      const payload = {
        name: form.name,
        description: form.description,
        price: Number(form.price),
        stock: Number(form.stock || 0),
        image: form.image,
        category: form.category
      };

      const created = await createProduct(payload);
      setSuccess('Product created successfully');
      setForm({ name: '', description: '', price: '', stock: '', image: '', category: '' });

      // prepend new product to UI list
      setProducts((prev) => [created, ...prev]);
    } catch (err) {
      setError(err.response?.data?.message || 'Error creating product');
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div>
      <Navbar bg="dark" variant="dark">
        <Navbar.Brand>{user?.name} ({user?.role})</Navbar.Brand>
        <Nav className="ms-auto">
          <Button variant="outline-light" onClick={handleLogout}>Logout</Button>
        </Nav>
      </Navbar>

      <Container style={{ marginTop: '20px' }}>
        <h3>Add Product</h3>
        {error && <p style={{ color: 'red' }}>{error}</p>}
        {success && <p style={{ color: 'green' }}>{success}</p>}

        <Form onSubmit={handleSubmit}>
          <Row>
            <Col md={6}>
              <Form.Group className="mb-2">
                <Form.Control name="name" placeholder="Name" value={form.name} onChange={handleChange} required />
              </Form.Group>
              <Form.Group className="mb-2">
                <Form.Control as="textarea" name="description" placeholder="Description" value={form.description} onChange={handleChange} />
              </Form.Group>
              <Form.Group className="mb-2">
                <Form.Control name="category" placeholder="Category" value={form.category} onChange={handleChange} />
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group className="mb-2">
                <Form.Control name="price" placeholder="Price" type="number" value={form.price} onChange={handleChange} required />
              </Form.Group>
              <Form.Group className="mb-2">
                <Form.Control name="stock" placeholder="Stock" type="number" value={form.stock} onChange={handleChange} />
              </Form.Group>
              <Form.Group className="mb-2">
                <Form.Control name="image" placeholder="Image URL" value={form.image} onChange={handleChange} />
              </Form.Group>
              <Button type="submit">Create Product</Button>
            </Col>
          </Row>
        </Form>

        <hr />
        <h4 className="mt-4">Products</h4>
        <Row className="mt-3">
          {products.map((p) => (
            <Col md={3} key={p._id} className="mb-3">
              <Card>
                <Card.Img variant="top" src={p.image || '/images/product-placeholder.png'} style={{ height: '180px', objectFit: 'cover' }} />
                <Card.Body>
                  <Card.Title>{p.name}</Card.Title>
                  <Card.Text>₹{p.price}</Card.Text>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>
    </div>
  );
}

export default AdminDashboard;
