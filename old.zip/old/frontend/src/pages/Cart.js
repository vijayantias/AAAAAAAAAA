import React, { useEffect, useContext } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { CartContext } from '../context/CartContext';
import { getProducts } from '../api/product';
import { Navbar, Button, Container } from "react-bootstrap";


function Cart() {
  const { id } = useParams();
  const { cart,addToCart } = useContext(CartContext);
  const navigate = useNavigate();

  useEffect(() => {
    const addProduct = async () => {
      if (!id) {
        navigate('/cart');
        return;
      }

      const productExists = cart.items.find(item => item.product._id === id);
      if (!productExists) {
      try {
        const products = await getProducts();
        const p = products.find(prod => prod._id === id);
        if (p) {
          await addToCart(p, 1);
        }
      } catch (err) {
        console.error('Error adding to cart:', err);
      }
    }
      navigate('/cart');
    };

    addProduct();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, cart.items]); // only run once for a given id

  return (
    <div>
      {/* Navbar */}
      <Navbar bg="dark" variant="dark">
        <Container>
          <Navbar.Brand>My Cart</Navbar.Brand>
          <Button variant="outline-light" onClick={() => navigate('/dashboard')}>
            Dashboard
          </Button>
        </Container>
      </Navbar>

      <div style={{ textAlign: 'center', marginTop: '50px' }}>
        <h2>Adding product to cart...</h2>
      </div>
    </div>
  );
} 

export default Cart;

