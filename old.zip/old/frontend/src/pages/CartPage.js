import { useContext, useEffect } from "react";
import { CartContext } from "../context/CartContext";
import { Navbar, Button, Container } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

function CartPage() {
  const { cart, increaseQuantity, decreaseQuantity, removeFromCart, fetchCart } =
    useContext(CartContext);
  const navigate = useNavigate();

  useEffect(() => {
    fetchCart();
  }, [fetchCart]);

  return (
    <div>
      {/* Navbar */}
      <Navbar bg="dark" variant="dark">
        <Container>
          <Navbar.Brand>My Cart</Navbar.Brand>
          <Button variant="outline-light" onClick={() => navigate('/dashboard')}>
            Dashboard
          </Button>
        </Container>
      </Navbar>


    <div style={{ padding: "20px" }}>
      <h2>Your Cart</h2>
      {cart.items.length === 0 ? (
        <p>Cart is empty</p>
      ) : (
        cart.items.map((item) => (
          <div 
            key={item.product._id} 
            style={{ borderBottom: "1px solid #ccc", margin: "10px 0" }}
          >
            <h4>{item.product.name}</h4>
          
            <p>
              Quantity:
              <button 
                onClick={() => decreaseQuantity(item.product._id)} 
                style={{ margin: "0 5px" }}>
                -
              </button>
              {item.quantity}

              <button 
                onClick={() => increaseQuantity(item.product._id)} 
                style={{ margin: "0 5px" }}>
                  +
              </button>

            </p>
            
            <p>
              Subtotal: ₹{(item.product.price * item.quantity).toFixed(2)}
            </p>

            <button onClick={() => removeFromCart(item.product._id)}>Remove</button>
          </div>
        ))
      )}
      <h3>Total: ₹{cart.total.toFixed(2)}</h3>

      {cart.items.length > 0 && (
        <Button 
          variant="success" 
          style={{ marginTop: "20px" }}
          onClick={() => navigate(`/checkout/${cart.items[0].product._id}`)}
        >
          Proceed to Checkout
        </Button>
      )}
    </div>

    </div>
  );
}

export default CartPage;
