// // NEW FINAL WITH PAYMENT -- NO UI
// import { useContext, useState } from "react";
// import { CartContext } from "../context/CartContext";
// import { loadStripe } from "@stripe/stripe-js";
// import { Elements, useStripe, useElements, CardElement } from "@stripe/react-stripe-js";
// import axios from "axios";

// const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_KEY);

// function CheckoutForm() {
//   const { cart, clearCart } = useContext(CartContext);
//   const stripe = useStripe();
//   const elements = useElements();
//   const [loading, setLoading] = useState(false);

//   const handlePayment = async () => {
//     if (!stripe || !elements) return;
//     setLoading(true);

//     try {
//       const token = localStorage.getItem("token");

//       // 1️⃣ Create PaymentIntent
//       const { data } = await axios.post(
//         `${process.env.REACT_APP_API_URL}/payment/create-payment-intent`,
//         { items: cart.items.map(item => ({
//           productId: item.product._id,
//           name: item.product.name,
//           quantity: item.quantity,
//           price: item.product.price,
//         })) },
//         { headers: { Authorization: `Bearer ${token}` } }
//       );

//       const clientSecret = data.clientSecret;

//       // 2️⃣ Confirm payment with card info
//       const { error, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
//         payment_method: { card: elements.getElement(CardElement) },
//       });

//       if (error) {
//         alert(error.message);
//         setLoading(false);
//         return;
//       }

//       if (paymentIntent.status === "succeeded") {
//         // 3️⃣ Call backend to save order
//         await axios.post(
//           `${process.env.REACT_APP_API_URL}/payment/confirm`,
//           { paymentIntentId: paymentIntent.id },
//           { headers: { Authorization: `Bearer ${token}` } }
//         );

//         alert("Payment successful and order placed!");
//         clearCart(); // Clear frontend cart
//       }
//     } catch (err) {
//       console.error(err);
//       alert("Payment failed. Try again!");
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div style={{ textAlign: "center", marginTop: "50px" }}>
//       <h2>Checkout</h2>
//       {cart.items.length === 0 ? <p>No items in cart.</p> : (
//         <>
//           <h3>Order Summary</h3>
//           {cart.items.map(item => (
//             <div key={item.product._id} style={{ marginBottom: "15px" }}>
//               <p><b>{item.product.name}</b> (x{item.quantity}) – ₹{item.product.price}</p>
//               <p>Subtotal: ₹{(item.product.price * item.quantity).toFixed(2)}</p>
//             </div>
//           ))}
//           <h3>Total: ₹{cart.total.toFixed(2)}</h3>

//           <div style={{ maxWidth: "400px", margin: "20px auto" }}>
//             <CardElement options={{ hidePostalCode: true }} />
//           </div>

//           <button
//             disabled={loading}
//             style={{
//               marginTop: "20px",
//               padding: "10px 20px",
//               background: "green",
//               color: "white",
//               border: "none",
//               cursor: "pointer",
//             }}
//             onClick={handlePayment}
//           >
//             {loading ? "Processing..." : "Proceed to Payment"}
//           </button>
//         </>
//       )}
//     </div>
//   );
// }

// export default function Checkout() {
//   return <Elements stripe={stripePromise}><CheckoutForm /></Elements>;
// }




// frontend/src/pages/Checkout.js -- WITH UI BUT REDIRECT TODIFFERENT PAGES
import { useContext } from "react";
import { CartContext } from "../context/CartContext";
import { useNavigate, useParams } from "react-router-dom";

export default function Checkout() {
  const { cart } = useContext(CartContext);
  const { orderId } = useParams(); // assuming backend creates order first
  const navigate = useNavigate();

  const handleProceed = () => {
    navigate(`/payment/${orderId}`);
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h2>Checkout</h2>
      {cart.items.length === 0 ? (
        <p>No items in cart.</p>
      ) : (
        <>
          <h3>Order Summary</h3>
          {cart.items.map((item) => (
            <div key={item.product._id} style={{ marginBottom: "15px" }}>
              <p>
                <b>{item.product.name}</b> (x{item.quantity}) – ₹{item.product.price}
              </p>
              <p>Subtotal: ₹{(item.product.price * item.quantity).toFixed(2)}</p>
            </div>
          ))}
          <h3>Total: ₹{cart.total.toFixed(2)}</h3>

          <button
            style={{
              marginTop: "20px",
              padding: "10px 20px",
              background: "blue",
              color: "white",
              border: "none",
              cursor: "pointer",
            }}
            onClick={handleProceed}
          >
            Proceed to Payment
          </button>
        </>
      )}
    </div>
  );
}
