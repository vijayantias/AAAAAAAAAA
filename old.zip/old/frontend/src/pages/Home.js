import { Link } from 'react-router-dom';
import { Carousel, Card, Button, Container, Row, Col, Navbar, Nav } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { getProducts } from '../api/product';
import { useContext } from "react";
import { CartContext } from "../context/CartContext";
import { AuthContext } from "../context/AuthContext";


function Home() {

  const { user } = useContext(AuthContext);

  const [products, setProducts] = useState([]);
  
  const navigate = useNavigate();
    
  // // Dummy images for carousel
  const carouselImages = [
    '/images/slide1.jpg',
    '/images/slide2.jpg',
    '/images/slide3.jpg',
    '/images/slide4.jpg',
    '/images/slide5.jpg'
  ];

  // // Dummy recent products
  // const recentProducts = [
  //   {
  //     id: 1,
  //     title: 'Product 1',
  //     description: 'Quick example text for product 1',
  //     image: '/images/product1.jpg'
  //   },
  //   {
  //     id: 2,
  //     title: 'Product 2',
  //     description: 'Quick example text for product 2',
  //     image: '/images/product2.jpg'
  //   },
  //   {
  //     id: 3,
  //     title: 'Product 3',
  //     description: 'Quick example text for product 3',
  //     image: '/images/product3.jpg'
  //   },
  //   {
  //     id: 4,
  //     title: 'Product 4',
  //     description: 'Quick example text for product 4',
  //     image: '/images/product4.jpg'
  //   }
  // ];

  const { addToCart } = useContext(CartContext);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getProducts();
        setProducts(data);
      } catch (err) {
        console.error('Error fetching products:', err);
      }
    };
    fetchData();
  }, []);


  return (
    <div>
      {/* Top Navbar */}
      <Navbar bg="dark" variant="dark" expand="lg">
        <Navbar.Brand href="/">Ecomm</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="ms-auto">
            <Link to="/login">
              <Button variant="outline-light" className="me-2">Login</Button>
            </Link>
            <Link to="/register">
              <Button variant="outline-light">Register</Button>
            </Link>
          </Nav>
        </Navbar.Collapse>
      </Navbar>

      {/* Welcome Message */}
      <div style={{ textAlign: 'center', marginTop: '50px' }}>
        <h1>Welcome to E-Commerce App</h1>
      </div>

      {/* Carousel */}
      <Container style={{ marginTop: '30px' }}>
        <Carousel>
          {carouselImages.map((img, idx) => (
            <Carousel.Item key={idx}>
              <img
                className="d-block w-100"
                src={img}
                alt={`Slide ${idx + 1}`}
                style={{ maxHeight: '400px', objectFit: 'cover' }}
              />
            </Carousel.Item>
          ))}
        </Carousel>
      </Container>

      {/* Recent Products */}
      {/* Recent Products */}
      <Container className="mt-4">
        <h3>Recent Products</h3>
        <Row className="mt-3">
          {products.length === 0 ? (
            <p>No products available</p>
          ) : (
            products.map((p) => (
              <Col md={3} key={p._id} className="mb-3">
                <Card>
                  <Card.Img
                    variant="top"
                    src={p.image || 'https://placehold.co/300x200'}
                    style={{ height: '180px', objectFit: 'cover' }}
                  />
                  <Card.Body>
                    <Card.Title>{p.name}</Card.Title>
                    <Card.Text>₹{p.price}</Card.Text>
                    <Card.Text>{p.description?.substring(0, 50)}...</Card.Text>
                    
                  {/* Add to Cart button */}
                  <Button
                    variant="primary"
                    style={{ marginRight: '10px' }}
                    onClick={() => navigate('/home2', { state: { action: 'cart', productId: p._id } })}
                  >
                    Add to Cart
                  </Button>

                  {/* Buy Now button */}
                  <Button
                    variant="success"
                    onClick={() => navigate('/home2', { state: { action: 'checkout', productId: p._id } })}
                  >
                    Buy Now
                  </Button>

                  </Card.Body>
                </Card>
              </Col>
            ))
          )}
        </Row>
      </Container>
    </div>
  );
}

export default Home;
