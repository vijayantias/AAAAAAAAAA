import { Link } from 'react-router-dom';
import { useLocation } from 'react-router-dom';

function Home2() { 
  const location = useLocation();
  const redirectTo = location.state?.redirectTo || null;

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Welcome to E-Commerce App</h1>
      <p>Please choose an option:</p>
      <div>
        <Link to="/login" state={{ from: redirectTo }}>
          <button style={{ margin: '10px' }}>Login</button>
        </Link>
        <Link to="/register" state={{ from: redirectTo }}>
          <button style={{ margin: '10px' }}>Register</button>
        </Link>
      </div>
    </div>
  );
}

export default Home2;
