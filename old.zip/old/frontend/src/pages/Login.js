import { useState, useContext } from 'react';
import { loginUser } from '../api/auth';
import { AuthContext } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { useLocation } from 'react-router-dom';


function Login() {
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    try {
    const data = await loginUser(form);
    login(data); // save user and token
    setSuccess('Login successful! Redirecting...');

    // Get redirect path: from state (string) or role-based dashboard
    const redirectTo = location.state?.from || (data.user.role === 'admin' ? '/admin' : '/dashboard');

    // Redirect after 1 second
    setTimeout(() => {
      navigate(redirectTo, { replace: true });
    }, 1000);

  } catch (err) {
    setError(err.response?.data?.message || 'Error logging in');
  }
  };

  return (
    <div>
      <h2>Login</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {success && <p style={{ color: 'green' }}>{success}</p>}
      <form onSubmit={handleSubmit}>
        <input
          name="email"
          placeholder="Email"
          type="email"
          value={form.email}
          onChange={handleChange}
          required
        />
        <input
          name="password"
          placeholder="Password"
          type="password"
          value={form.password}
          onChange={handleChange}
          required
        />
        <button type="submit">Login</button>
      </form>
    </div>
  );
}

export default Login;
