// frontend/src/pages/OrderSuccess.js
import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import axios from "axios";

export default function OrderSuccess() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [status, setStatus] = useState("processing");


  useEffect(() => {
    const redirectStatus = searchParams.get("redirect_status");
    const paymentIntentId = searchParams.get("payment_intent");
    setStatus(redirectStatus || "processing");


    const saveOrder = async () => {
      try {
        if (redirectStatus === "succeeded" && paymentIntentId) {
          const token = localStorage.getItem("token");
          await axios.post(
            `${process.env.REACT_APP_API_URL}/payment/confirm`,
            { paymentIntentId },
            { headers: { Authorization: `Bearer ${token}` } }
          );
        }
      } catch (err) {
        console.error("Order save failed:", err.response?.data || err);
      }
    }

    saveOrder();

    // Auto redirect after 3 sec
    const timer = setTimeout(() => {
      navigate("/dashboard");
    }, 3000);

    return () => clearTimeout(timer);
  }, [searchParams, navigate]);

  return (
    <div style={{ textAlign: "center", marginTop: "80px" }}>
      {status === "succeeded" && (
        <>
          <h2 style={{ color: "green" }}>✅ Payment Successful</h2>
          <p>You will be redirected to your dashboard in 3 seconds...</p>
        </>
      )}
      {status === "failed" && (
        <>
          <h2 style={{ color: "red" }}>❌ Payment Failed</h2>
          <p>Please try again. Redirecting to dashboard...</p>
        </>
      )}
      {status === "processing" && (
        <>
          <h2>⏳ Payment Processing</h2>
          <p>We are verifying your payment...</p>
        </>
      )}
    </div>
  );
}
