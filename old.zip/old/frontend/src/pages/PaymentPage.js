// frontend/src/pages/PaymentPage.js
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { loadStripe } from "@stripe/stripe-js";
import { Elements } from "@stripe/react-stripe-js";
import CheckoutForm from "../components/CheckoutForm"; // a NEW file

const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_KEY);

export default function PaymentPage() {
  const { orderId } = useParams();
  const [clientSecret, setClientSecret] = useState("");

  useEffect(() => {
    const token = localStorage.getItem("token");

    // fetch clientSecret from backend
    fetch(`${process.env.REACT_APP_API_URL}/payment/create-payment-intent`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ orderId }), // backend should accept this
    })
      .then((res) => res.json())
      .then((data) => setClientSecret(data.clientSecret));
  }, [orderId]);

  const options = { clientSecret, appearance: { theme: "stripe" } };

  return (
    <div style={{ maxWidth: "500px", margin: "0 auto" }}>
      <h2>Secure Payment</h2>
      {clientSecret && (
        <Elements stripe={stripePromise} options={options}>
          <CheckoutForm />
        </Elements>
      )}
    </div>
  );
}
