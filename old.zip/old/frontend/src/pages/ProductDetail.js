import { useParams } from 'react-router-dom';

function ProductDetail() {
  const { id } = useParams(); // get product id from URL

  // For now, we can just show the product ID
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h2>Product Details</h2>
      <p>Product ID: {id}</p>
      <p>Here you can later show full product info, Buy Now, Add to Cart, etc.</p>
    </div>
  );
}

export default ProductDetail;
