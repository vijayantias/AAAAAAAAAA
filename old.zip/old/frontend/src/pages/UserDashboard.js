// NO ORDER DETAILS
// import { useContext, useEffect, useState } from 'react';
// import { useNavigate } from 'react-router-dom';
// import { AuthContext } from '../context/AuthContext';
// import { getProducts } from '../api/product';
// import { Navbar, Nav, Button, Container, Row, Col, Card } from 'react-bootstrap';


// function UserDashboard() {
//   const { user, logout } = useContext(AuthContext);
//   const [products, setProducts] = useState([]);
//   const navigate = useNavigate();

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const data = await getProducts();
//         setProducts(data);
//       } catch (err) {
//         console.error('Error fetching products:', err);
//       }
//     };
//     fetchData();
//   }, []);

//   return (
//     <div>
//       {/* Navbar */}
//       <Navbar bg="dark" variant="dark">
//         <Navbar.Brand>{user?.name} ({user?.role})</Navbar.Brand>
//         <Nav className="ms-auto">
//           <Navbar.Text className="me-3">
//             {user?.name} ({user?.role})
//           </Navbar.Text>

//           <Button 
//             variant='warning' 
//             className='me-2' 
//             onClick={() => navigate('/cart')}
//           > 
//             Cart
//           </Button>

//           <Button 
//             variant="outline-light" 
//             onClick={() => { logout(); navigate('/'); }}>
//             Logout
//           </Button>
//         </Nav>
//       </Navbar>

//       {/* Products */}
//       <Container className="mt-4">
//         <h3>Available Products</h3>
//         <Row className="mt-3">
//           {products.length === 0 ? (
//             <p>No products available</p>
//           ) : (
//             products.map((p) => (
//               <Col md={3} key={p._id} className="mb-3">
//                 <Card>
//                   <Card.Img
//                     variant="top"
//                     src={p.image || 'https://placehold.co/300x200'}
//                     style={{ height: '180px', objectFit: 'cover' }}
//                   />
//                   <Card.Body>
//                     <Card.Title>{p.name}</Card.Title>
//                     <Card.Text>₹{p.price}</Card.Text>
//                     <Card.Text>{p.description?.substring(0, 50)}...</Card.Text>

//                     <Button
//                       variant="primary"
//                       style={{ marginRight: '10px' }}
//                       onClick={() => {
//                         if (!user) {
//                           // Not logged in → go to login
//                           navigate('/home2', { state: { action: 'cart', productId: p._id } });
//                         } else {
//                           // Logged in → go to cart/:id
//                           // navigate('/cart', { state: { productId: p._id } });
//                           navigate(`/cart/${p._id}`);
//                         }
//                       }}
//                     >
//                       Add to Cart
//                     </Button>


//                     <Button
//                       variant="success"
//                       onClick={() => {
//                         if (!user) {
//                           // Not logged in → go to login
//                           navigate('/home2', { state: { action: 'buy', productId: p._id } });
//                         } else {
//                           // Logged in → go to checkout/:id
//                           // navigate('/checkout', { state: { productId: p._id } });
//                           navigate(`/checkout/${p._id}`);
//                         }
//                       }}
//                     >
//                       Buy Now
//                     </Button>


//                   </Card.Body>
//                 </Card>
//               </Col>
//             ))
//           )}
//         </Row>
//       </Container>
//     </div>
//   );
// }

// export default UserDashboard;



// frontend/src/pages/UserDashboard.js
import { useContext, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { getProducts } from '../api/product';
import axios from 'axios';
import { Navbar, Nav, Button, Container, Row, Col, Card } from 'react-bootstrap';

function UserDashboard() {
  const { user, logout } = useContext(AuthContext);
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const data = await getProducts();
        setProducts(data);
      } catch (err) {
        console.error('Error fetching products:', err);
      }
    };

    const fetchOrders = async () => {
      try {
        const token = localStorage.getItem('token');
        const { data } = await axios.get(
          `${process.env.REACT_APP_API_URL}/orders/my-orders`,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        setOrders(data);
      } catch (err) {
        console.error('Error fetching orders:', err);
      }
    };

    fetchProducts();
    fetchOrders();
  }, []);

  return (
    <div>
      {/* Navbar */}
      <Navbar bg="dark" variant="dark">
        <Navbar.Brand>{user?.name} ({user?.role})</Navbar.Brand>
        <Nav className="ms-auto">
          <Navbar.Text className="me-3">{user?.name} ({user?.role})</Navbar.Text>
          <Button variant='warning' className='me-2' onClick={() => navigate('/cart')}>Cart</Button>
          <Button variant="outline-light" onClick={() => { logout(); navigate('/'); }}>Logout</Button>
        </Nav>
      </Navbar>

      {/* Products */}
      <Container className="mt-4">
        <h3>Available Products</h3>
        <Row className="mt-3">
          {products.length === 0 ? (
            <p>No products available</p>
          ) : (
            products.map((p) => (
              <Col md={3} key={p._id} className="mb-3">
                <Card>
                  <Card.Img
                    variant="top"
                    src={p.image || 'https://placehold.co/300x200'}
                    style={{ height: '180px', objectFit: 'cover' }}
                  />
                  <Card.Body>
                    <Card.Title>{p.name}</Card.Title>
                    <Card.Text>₹{p.price}</Card.Text>
                    <Card.Text>{p.description?.substring(0, 50)}...</Card.Text>
                    <Button
                      variant="primary"
                      onClick={() => {
                        if (!user) {
                          navigate('/home2', { state: { action: 'cart', productId: p._id } });
                        } else {
                          navigate(`/cart/${p._id}`);
                        }
                      }}
                    >
                      Add to Cart
                    </Button>
                  </Card.Body>
                </Card>
              </Col>
            ))
          )}
        </Row>

        {/* User Orders */}
        <h3 className="mt-5">My Orders</h3>
        {orders.length === 0 ? (
          <p>No orders yet.</p>
        ) : (
          <Row className="mt-3">
            {orders.map((order) => (
              <Col md={4} key={order._id} className="mb-3">
                <Card>
                  <Card.Body>
                    <Card.Title>Order #{order._id}</Card.Title>
                    <Card.Text><b>Payment ID:</b> {order.paymentId}</Card.Text>
                    <Card.Text><b>Payment Status:</b> {order.paymentStatus}</Card.Text>
                    <Card.Text><b>Order Status:</b> {order.orderStatus}</Card.Text>
                    <Card.Text><b>Total:</b> ₹{order.total}</Card.Text>
                    <Card.Text>
                      <b>Items:</b>
                      <ul>
                        {order.items.map((i) => (
                          <li key={i.product._id}>{i.product.name} x{i.quantity} - ₹{i.price}</li>
                        ))}
                      </ul>
                    </Card.Text>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        )}
      </Container>
    </div>
  );
}

export default UserDashboard;
